#include <iostream>

class Plus
{
public:
	int operator()(int a, int b) const
	{
		return a + b;
	}
};

int main()
{
	Plus p;
	int n = p(1, 2);

	// a + b;
	// a - b;
	// a();
	// a(1,2);
}