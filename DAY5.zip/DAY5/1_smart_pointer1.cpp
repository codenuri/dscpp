#include <iostream>

class Car
{
public:
	void Go() { std::cout << "Car Go\n"; }
	~Car()    { std::cout << "~Car\n"; }
};

int main()
{
	Car* p = new Car;
	p->Go();
}