﻿// 1_레퍼런스.cpp    57 page

#include <iostream>

int main()
{
	int n1 = 10;

	int& r1 = n1;

	r1 = 30;

	std::cout << n1  << std::endl; // ?
	
	std::cout << &r1 << std::endl;
	std::cout << &n1 << std::endl;

	// & 연산자의 3가지 용도
	int n = 3 & 4;
	int* p = &n;
	int& r = n;

	// 포인터 변수 초기화 vs 레퍼런스 초기화
}



