﻿// 6_초기화리스트1    89page ~
#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a, int b) 		
	{
		x = a; 
		y = b; 
	}
};
int main()
{
	Point pt{ 0, 0 };
}




