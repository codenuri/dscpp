#include <iostream>

// friend 79page ~

class Bike
{
	int gear = 0;
public:
	void set_gear(int n) { gear = n; }
};

void bike_repair(Bike& b)
{
	b.gear = 10;
}

int main()
{
	Bike b;
	bike_repair(b);
}