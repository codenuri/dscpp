// �߻�Ŭ���� - 156page

class Shape
{
public:
	virtual void draw()  = 0;
};
class Rect : public Shape
{
public:
};
int main()
{
	Shape s; // ?
	Rect  r; // ?
}


