// 6_cout - 187page
#include <iostream>

int main()
{
	std::cout << "A" << "B" << "C";

	int    n = 10;
	double d = 3.4;

	std::cout << n; // cout.operator<<(int)
	std::cout << d; // cout.operator<<(double)
}


