#include <iostream>

class Point
{
	int x;
	int y;
public:
	Point(int x, int y) : x{ x }, y{ y } {}
};

int main()
{
	Point p(1, 2);

	std::cout << p ;
					
					
					
}


