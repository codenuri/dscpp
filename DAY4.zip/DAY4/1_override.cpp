﻿// override  145 page ~

class Animal
{
public:
	virtual void cry() {}
};
class Dog : public Animal
{
public:
	// #1. 가상함수 재정의시 virtual 은 표기해도 되고 없어도 됩니다.
	virtual void cry()  {}
};

int main()
{

}
