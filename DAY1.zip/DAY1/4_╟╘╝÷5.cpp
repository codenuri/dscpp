﻿//  후위 반환 타입 - 42page

int square(int a)
{
	return a * a;
}
int main()
{
	square(3);
}
