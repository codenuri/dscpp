﻿// 28 page ~

int main()
{
	int x[3] = { 1,2,3 };

	int n = x[0];

}
