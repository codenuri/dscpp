﻿
class Rect
{
	int x, y, w, h;
public:
	Rect(int a, int b, int c, int d)
		: x{ a }, y{ b }, w{ c }, h{ d } {}

	int get_area() { return w * h; }
};
void foo(Rect r)
{
	int n = r.get_area();
}

int main()
{
	Rect r{ 1, 1, 10, 10 };	
	int n = r.get_area();
	foo(r);
}



