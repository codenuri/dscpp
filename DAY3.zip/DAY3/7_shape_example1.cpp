﻿// 예제1     149 page
#include <iostream>
#include <vector>

// 파워 포인트 같은프로그램을 객체지향으로 만드는 것을 생각해 봅시다.

int main()
{
}



