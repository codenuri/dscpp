﻿// 3_정적멤버1 - 111 page
#include <iostream>

// Car 객체의 갯수를 관리하고 싶다.

class Car
{
	int color;
public:
	Car()  {  }
	~Car() {  }
};

int main()
{
	Car c1;
	Car c2;
}

