﻿#include <iostream>
#include <vector>

class People
{
	std::string name;
	int age;
public:
};

int main()
{
	People p;
}



