﻿#include <vector>

class Animal
{
public:	int age;
};
class Dog : public Animal
{
public:	int color;
};
class Cat : public Animal
{
public:	int speed;
};
// upcasting 의 활용

void new_year(Dog* p)
{
	++(p->age);
}

int main()
{	
	Dog dog; new_year(&dog);
	Cat cat; new_year(&cat);

	std::vector<Dog*> v1;
}
